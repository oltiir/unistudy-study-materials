<?php
$pageTitle = 'News - UBT';
$currentPage = 'news';
include 'header.php';
?>

<section class="hero">
    <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
    <p>Latest updates and announcements from UBT.</p>
</section>

<section class="cards">
    <div class="card">
        <h2>UBT recognized among top universities</h2>
        <p>UBT has been ranked among leading institutions for innovation and student engagement.</p>
    </div>
    <div class="card">
        <h2>New academic year 2025/2026</h2>
        <p>Applications are open for the upcoming academic year. Students can apply online through the portal.</p>
    </div>
    <div class="card">
        <h2>International partnerships</h2>
        <p>UBT continues to expand its global network of partner universities and institutions.</p>
    </div>
</section>

<?php include 'footer.php'; ?>


