<?php
$pageTitle = 'About - UBT';
$currentPage = 'about';
include 'header.php';
?>

<section class="hero">
    <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
    <p>UBT is a higher education institution focused on modern study programs, research, and innovation.</p>
</section>

<section class="cards">
    <div class="card">
        <h2>Our Mission</h2>
        <p>To provide top-quality education and prepare students for the demands of the global labor market.</p>
    </div>
    <div class="card">
        <h2>Our Community</h2>
        <p>Thousands of students, alumni, and staff form an active academic and professional network.</p>
    </div>
</section>

<?php include 'footer.php'; ?>


