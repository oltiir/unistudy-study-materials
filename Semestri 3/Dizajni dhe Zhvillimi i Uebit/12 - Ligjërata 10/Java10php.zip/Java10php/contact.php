<?php
$pageTitle = 'Contact - UBT';
$currentPage = 'contact';
include 'header.php';
?>

<section class="hero">
    <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
    <p>Get in touch with UBT for information about programs, admissions, and student services.</p>
</section>

<section class="cards">
    <div class="card">
        <h2>Contact information</h2>
        <p>You can contact us by phone, email, or by visiting our main campus in Prishtina.</p>
    </div>
</section>

<?php include 'footer.php'; ?>


