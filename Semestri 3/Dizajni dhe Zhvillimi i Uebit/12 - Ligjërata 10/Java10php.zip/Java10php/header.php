<?php
if (!isset($pageTitle)) {
    $pageTitle = 'Basic PHP Project';
}
if (!isset($currentPage)) {
    $currentPage = 'home';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <header class="site-header">
        <div class="logo">
            <span class="logo-text">UBT</span>
        </div>
        <nav class="main-nav">
            <!-- condition ? value_if_true : value_if_false -->
            <!-- If true (?) → return 'active'
            If false (:) → return an empty string '' -->
            <a href="index.php" class="<?php echo $currentPage === 'home' ? 'active' : ''; ?>">Home</a>
            <a href="about.php" class="<?php echo $currentPage === 'about' ? 'active' : ''; ?>">About</a>
            <a href="news.php" class="<?php echo $currentPage === 'news' ? 'active' : ''; ?>">News</a>
            <a href="contact.php" class="<?php echo $currentPage === 'contact' ? 'active' : ''; ?>">Contact</a>
        </nav>
    </header>
    <main class="content">


