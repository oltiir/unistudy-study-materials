<?php
$pageTitle = 'Home - UBT';
$currentPage = 'home';
include_once 'header.php';


?>

<section class="hero">
    <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
    <p>Welcome to UBT, a higher education institution dedicated to innovation, quality teaching, and student success.</p>
</section>

<section class="cards">
    <div class="card">
        <h2>Study Programs</h2>
        <p>Discover bachelor and master programs in technology, business, architecture, and more.</p>
    </div>
    <div class="card">
        <h2>Modern Campus</h2>
        <p>Learn in a dynamic environment equipped with laboratories, hubs, and collaborative spaces.</p>
    </div>
    <div class="card">
        <h2>International Opportunities</h2>
        <p>Join mobility programs and international projects with partner universities worldwide.</p>
    </div>
</section>

<?php include 'footer.php'; ?>


