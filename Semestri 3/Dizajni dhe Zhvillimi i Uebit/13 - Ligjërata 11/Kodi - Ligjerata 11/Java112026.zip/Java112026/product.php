<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Titulli</h1>
    <h4>Description</h4>
    <h2>price</h2>

    <?php 
    echo "ID: ".$_GET['id'];
    ?>
</body>
</html>