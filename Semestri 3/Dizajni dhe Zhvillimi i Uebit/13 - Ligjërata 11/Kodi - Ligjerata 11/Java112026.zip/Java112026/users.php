<?php

$user1=[
     "name"=>"Greta",
     "surname"=>"Ahma",
     "email"=>"gretaahma@gmail.com",
     "username"=>"gretaahma",
     "password"=>"greta123",
     "role"=>"user"
];

$user2=[
    "name"=>"Betim",
    "surname"=>"Gashi",
    "email"=>"betimgashi@hotmail.com",
    "username"=>"betimgashi",
    "password"=>"betim123",
    "role"=>"admin"
];


$users=[$user1,$user2];


?>