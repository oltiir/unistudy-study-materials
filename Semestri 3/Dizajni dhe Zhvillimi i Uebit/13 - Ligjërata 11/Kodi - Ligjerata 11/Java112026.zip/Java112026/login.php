<?php
session_start();

if(isset($_SESSION['username'])){
   header("location:home.php");
}else{



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="loginValidate.php" method="post">
        <input type="text" name="username" placeholder="username..." > <br><br>
        <input type="password" name="password" placeholder="password..."> <br><br>

        <input type="submit" value="login" name="loginBtn">
    </form>
</body>
</html>

<?php 

}
?>